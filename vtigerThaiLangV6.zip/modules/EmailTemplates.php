<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'LBL_ADD_RECORD' => 'เพิ่มอีเมลล์เทมเพลต',
	'SINGLE_EmailTemplates' => 'อีเมลล์เทมเพลต',
	'LBL_EMAIL_TEMPLATES'=> 'อีเมลล์เทมเพลต',
	'LBL_EMAIL_TEMPLATE' => 'อีเมลล์เทมเพลต',
	
	'LBL_TEMPLATE_NAME' => 'ชื่อเทมเพลต',
	'LBL_DESCRIPTION' => 'รายละเอียด',
	'LBL_SUBJECT' => 'หัวข้อ',
	'LBL_GENERAL_FIELDS' => 'General Fields',
	'LBL_SELECT_FIELD_TYPE' => 'Select Field Type',
	
	'LBL_EMAIL_TEMPLATE_DESCRIPTION'=>'Manage templates for E-Mail module',
	
);
